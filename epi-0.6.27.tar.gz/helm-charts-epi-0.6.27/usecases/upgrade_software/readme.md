DcoumeQuestionsnt the process of updating to future versions of the use case

Issues:
 - keep 2 version in paralel
 - cannary deplyment
 - 
