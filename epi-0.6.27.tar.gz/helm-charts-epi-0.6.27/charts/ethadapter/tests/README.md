# Helm Unittests

## IMPORTANT

All test files must end with suffix `_test.yaml`, e.g. `default_test.yaml`

## Links

See [https://github.com/quintush/helm-unittest](https://github.com/quintush/helm-unittest)